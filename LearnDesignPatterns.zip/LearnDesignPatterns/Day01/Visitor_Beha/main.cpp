
class MetricCalculator;

class Shape
{
public:
	virtual double Invoke(MetricCalculator &mc) = 0;
};

class Rectangle : public Shape
{
public:
	Rectangle(int x1, int x2, int y1, int y2) : m_x1(x1), m_x2(x2), m_y1(y1), m_y2(y2) {}

public:
	int Getx1() const { return m_x1;}
	int Getx2() const { return m_x2; }
	int Gety1() const { return m_y1; }
	int Gety2() const { return m_y2; }

public:
	double Invoke(MetricCalculator &mc);
private:
	int m_x1;
	int m_x2;
	int m_y1;
	int m_y2;
};

class Circle : public Shape
{
public:	
	Circle(int r) : m_r(r) {}
public:
	double Invoke(MetricCalculator &mc);
public:
	int GetR() const { return m_r; }
private:
	int m_r;
};

class MetricCalculator
{
public:
	virtual double Compute(const Rectangle &r) = 0;
	virtual double Compute(const Circle &c) = 0;
};

class AreaCalculator : public MetricCalculator
{
public:
	double Compute(const Rectangle &r)
	{
		double l = r.Getx2() - r.Getx1();
		double w = r.Gety2() - r.Gety1();
		return l*w;
	}
	double Compute(const Circle &c)
	{
		return 3.14*c.GetR()*c.GetR();
	}

};

class PerimeterCalculator : public MetricCalculator
{
public:
	double Compute(const Rectangle &r)
	{
		double l = r.Getx2() - r.Getx1();
		double w = r.Gety2() - r.Gety1();
		return l+w;
	}
	double Compute(const Circle &c)
	{
		return 2*3.14*c.GetR();
	}

};

double Rectangle::Invoke(MetricCalculator &mc)
{
	return mc.Compute(*this);
}
double Circle::Invoke(MetricCalculator & mc)
{
	return mc.Compute(*this);
}

int main()
{
	double result = 0.0;
	Rectangle r1(10, 20, 30, 40);
	Circle c1 (15);

	AreaCalculator ac;
	result = r1.Invoke(ac);
	result = c1.Invoke(ac);

	PerimeterCalculator pc;
	result = r1.Invoke(pc);
	result = c1.Invoke(pc);

}