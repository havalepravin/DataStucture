#pragma once
#include "AdapterMethod.h"
#include "..\FactoryMethod_creat\FactoryMethod.h"
#include<memory>
using namespace std;


int main()
{
	double results = 0;
	unique_ptr <RealCalculator> realCalculator(new RealCalculator);
	results = realCalculator->Add(1.0, 2.0);
	results = realCalculator->Sub(1.0, 2.0);
}