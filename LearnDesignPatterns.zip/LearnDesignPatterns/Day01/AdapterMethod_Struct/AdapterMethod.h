#pragma once
#include "..\FactoryMethod_creat\FactoryMethod.h"
#include<memory>
using namespace std;
//Targer

class IRealCalculator
{
public:
	virtual double Add(double u, double v) = 0;
	virtual double Sub(double u, double v) = 0;
};

class RealCalculator : public IRealCalculator
{
public:
	double Add(double u, double v)
	{
		unique_ptr <RealAdderFactory> realAdderFactory(new RealAdderFactory);
		unique_ptr <RealAdderBase> realAdder(realAdderFactory->CreateRealAdder());
		double results = realAdder->Add(u, v);
		return results;
	}
	double Sub(double u, double v)
	{
		unique_ptr <RealAdderFactory> realAdderFactory(new RealAdderFactory);
		unique_ptr <RealAdderBase> realAdder(realAdderFactory->CreateRealAdder());
		double results = realAdder->Add(u, -v);
		return results;
	}

};
