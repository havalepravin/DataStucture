
#include <Windows.h>
#include <assert.h>
#include <sstream>

#include "..\AdapterMethod_Struct\AdapterMethod.h" 
using namespace  std;

class RealCalculatorClient : public IRealCalculator
{
public:
	RealCalculatorClient()
	{
		m_hpipe = CreateFile(TEXT("\\\\.\\pipe\\RealCalculatorServer"),
			GENERIC_READ | GENERIC_WRITE,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	}
	~RealCalculatorClient()
	{
		SendMsg("End");
		CloseHandle(m_hpipe);
	}
public:
	double Add(double u, double v)
	{
		CHAR buffer[m_size];
		sprintf_s(buffer, m_size, "Add %lf %lf", u, v);
		SendMsg(buffer);
		while (!ReceiveMsg(buffer, m_size))
		{
			Sleep(100);
		}
		
		double results = 0.0;
		istringstream iss(buffer);
		iss >> results;

		return results;
	}
	double Sub(double u, double v)
	{
		CHAR buffer[m_size];
		sprintf_s(buffer, m_size, "Sub %lf %lf", u, v);
		SendMsg(buffer);
		while (!ReceiveMsg(buffer, m_size))
		{
			Sleep(100);
		}

		double results = 0.0;
		istringstream iss(buffer);
		iss >> results;

		return results;
	}
private:
	BOOL SendMsg(LPSTR message)
	{
		assert(message != nullptr);
		DWORD byteToWrite = strlen(message) + 1;
		return WriteFile(m_hpipe, message, byteToWrite, NULL, NULL);
	}
	DWORD ReceiveMsg(LPSTR message, DWORD size)
	{
		DWORD byteToRead = size;
		return ReadFile(m_hpipe, message, byteToRead, NULL, NULL);
	}
private:
	HANDLE m_hpipe;
private:
	static const size_t m_size = 64;

};

int main()
{
	double result = 0.0;
	RealCalculatorClient client;
	result = client.Add(1.0, 2.0);
	result = client.Sub(1.0, 2.0);
	return 0;
}