#include <memory>
#include <string>
#include <sstream>
#include <iostream>
#include <Windows.h>
#include <assert.h>

using namespace std;

#include "..\AdapterMethod_Struct\AdapterMethod.h"

class RealCalculatorStub
{
public:
	RealCalculatorStub()
	{
		m_hpipe = CreateNamedPipe(TEXT("\\\\.\\pipe\\RealCalculatorServer"),
			PIPE_ACCESS_DUPLEX, PIPE_TYPE_BYTE,
			PIPE_UNLIMITED_INSTANCES, 64, 64, 0, NULL);
	}
	~RealCalculatorStub()
	{
		CloseHandle(m_hpipe);
	}

public:
	void Run()
	{
		CHAR buffer[m_size], verb[m_size];
		double u = 0.0, v = 0.0, results = 0.0;
		DWORD bytesToRead = m_size;
		
		do {
			if (!ReceiveMsg(buffer, bytesToRead))
			{
				Sleep(100);
				continue;
			}

			istringstream ss(buffer);
			ss >> verb;

			if (strcmp(verb, "Add") == 0)
			{
				ss >> u >> v;
				results = m_realCalcultor.Add(u, v);
				sprintf_s(buffer, m_size, "%lf", results);
				SendMsg(buffer);
			}
			else if (strcmp(verb, "Sub") == 0)
			{
				ss >> u >> v;
				results = m_realCalcultor.Sub(u, v);
				sprintf_s(buffer, m_size, "%lf", results);
				SendMsg(buffer);
			}
			else if (strcmp(verb, "End") == 0)
			{
				break;
			}
		
		} while (1);
	}

private:
	BOOL SendMsg(LPSTR message)
	{
		assert(message != nullptr);
		DWORD byteToWrite = strlen(message) + 1;
		return WriteFile(m_hpipe, message, byteToWrite, NULL, NULL);
	}
	DWORD ReceiveMsg(LPSTR message, DWORD size)
	{
		DWORD byteToRead = size;
		return ReadFile(m_hpipe, message, byteToRead, NULL, NULL);
	}
private:
	HANDLE m_hpipe;
	RealCalculator m_realCalcultor;
private:
	static const size_t m_size = 64;
};

int main()
{
	RealCalculatorStub realCalculatorStub;
	realCalculatorStub.Run();
}