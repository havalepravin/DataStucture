//#include <bits/stdc++.h>
#include <vector>
using namespace std;

class Resister
{
public:
	virtual double GetResister() = 0;

};

class SimpleResister : public Resister
{
public:
	SimpleResister(double resistence) : m_resistence(resistence) {}

public:
	double  GetResister() { return m_resistence; }

private:
	double m_resistence;
};

class ResisterCollection : public Resister
{
public: 
	void AddResister(Resister &presister)
	{
		m_resister.push_back(&presister);
	}
	vector<Resister*>&  GetResistors() { return m_resister; }
private:
	vector<Resister*> m_resister;
};

class SerialResister : public ResisterCollection
{
public:
	double GetResister()
	{
		double totalResistence = 0.0;
		for (auto presister : GetResistors())
		{
			totalResistence += presister->GetResister();
		}
		return totalResistence;
	}
};

class ParallelResister : public ResisterCollection
{
public:
	double GetResister()
	{
		double totalResistence = 0.0;
		for (auto presister : GetResistors())
		{
			totalResistence += 1.0/presister->GetResister();
		}
		return totalResistence;
	}
};

int main()
{
	double results = 0.0;
	SimpleResister r1(10), r2(20);
	SerialResister sr3;
	sr3.AddResister(r1);
	sr3.AddResister(r2);

	results = sr3.GetResister();
	
	
	SimpleResister r11(10), r12(20);
	ParallelResister pr4;
	pr4.AddResister(r11);
	pr4.AddResister(r12);

	results = pr4.GetResister();

	{
		SimpleResister r11(10), r12(150), r13(25), r14(60), r15(45);
	}
	
	return 0;
}