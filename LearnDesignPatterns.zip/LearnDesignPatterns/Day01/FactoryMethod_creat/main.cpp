// User
#include "FactoryMethod.h"
#include<memory>
#include<crtdbg.h>
using namespace std;
int main() //step2
{
	//RealAdder *prealAdder = new RealAdder();
	//unique_ptr <RealAdderBase> prealAdder(new RealAdder());
	{
		unique_ptr<RealAdderFactory> realAdderFactory(new RealAdderFactory);

		unique_ptr <RealAdderBase> realAdder(realAdderFactory->CreateRealAdder());

		double u = 1.0, v = 2.0, results = 0.0;
		results = realAdder->Add(u, v);
	}
	_CrtDumpMemoryLeaks();
/*
	delete prealAdder;
	prealAdder = nullptr;
*/
}



//Use smart pointer in such cases- Release line of code with the same behavior no need to take care of object 
//destruction