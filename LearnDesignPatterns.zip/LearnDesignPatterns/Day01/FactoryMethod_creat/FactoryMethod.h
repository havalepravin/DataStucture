#pragma once
// Author
class RealAdderBase//step3
{
public:
	virtual ~RealAdderBase() {}
public:
	virtual double Add(double u, double v) = 0;
};

class RealAdder : public RealAdderBase //Step1
{
public:
	double Add(double u, double v) { return u + v; }
};

class IRealAdderFactory //step5
{
public:
	virtual RealAdderBase* CreateRealAdder() = 0;

};

class RealAdderFactory: public IRealAdderFactory {
public:
	RealAdderBase *CreateRealAdder() //step4
	{
		return new RealAdder();
	}
};
